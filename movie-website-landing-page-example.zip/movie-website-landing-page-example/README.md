# Movie Website Landing Page Example

A Pen created on CodePen.

Original URL: [https://codepen.io/Kiran-Gowda-the-bold/pen/NPRmGya](https://codepen.io/Kiran-Gowda-the-bold/pen/NPRmGya).

Source: codewithsadee (https://www.youtube.com/watch?v=-ex2BO2DG2s)